<?php
include('dbconnection.php');
session_start();

// Check if session is set, if not redirect to login
if (!isset($_SESSION['gid'])) {
    echo "<script>alert('Session expired, please login again!'); window.location.href = 'index.php';</script>";
    exit();
}

$gd = $_SESSION['gid']; // Get user id from session

// If form is submitted
if (isset($_POST['submit'])) {

    $password = $_POST['pass'];

    // Password Hashing for security
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Prepare and bind query to avoid SQL injection
    $stmt = $dbcon->prepare("UPDATE `login` SET `password` = ? WHERE `u_id` = ?");
    $stmt->bind_param("si", $hashedPassword, $gd); // "si" means string and integer for the params

    // Execute the query
    if ($stmt->execute()) {
        // If password updated, log out and redirect to login
        echo "<script>alert('Password Updated Successfully :)'); window.open('logout.php', '_self');</script>";
    } else {
        echo "<script>alert('Failed to update password, please try again!');</script>";
    }

    // Close statement
    $stmt->close();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Pswd</title>
    <style>
        body {
            background-image: url('images/Reset.jpg');
            background-repeat: no-repeat;
            background-size: cover;
        }
    </style>
</head>

<body>
    <form action="reset.php" method="POST">
        <table border="0px solid" style="margin-left: auto; margin-right:auto; margin-top:70px; font-weight:bold;border-spacing: 50px 30px;">
            <th colspan="3" style="text-align: center;font-size:35px; width: 300px; height: 70px;font-weight:bold;">Set New Password</th>
            <tr>
                <td colspan="2" style="font-size: 20px;font-weight:bold">New Password</td>
                <td><input type="password" name="pass" placeholder="Enter new password" style="font-size: 20px;font-weight:bold" required /></td>
            </tr>

            <tr>
                <td colspan="3" align="center">
                    <input type="submit" name="submit" value="Update" style="background-color: red; border-radius: 15px; width: 140px; height: 50px;" />
                </td>
            </tr>
        </table>

    </form>
</body>

</html>

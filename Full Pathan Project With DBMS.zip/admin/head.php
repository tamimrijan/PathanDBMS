<!-- Admin header style for Admin pages -->

<!DOCTYPE html>
<html>
	<head>
		<title>Header Demo</title>
		<meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <style>
            *{
        margin: 0;
        padding: 0;
    
        background-repeat: no-repeat;
        }
        /* body {
        background-image: url('../images/plane.jpg');
        background-size: cover;
        } */

        .admintitle{
            position: relative;
            background-color: brown;
            color: #fff;
            height: 100px;
            line-height: 140px;

        }
        </style>
    </head>
	<body bgcolor="#067d64">

    
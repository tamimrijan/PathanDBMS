<?php

    $dbcon = mysqli_connect('localhost','pathanbd','gameloft101cpanel','pathanbd_courierdb');

    if($dbcon==false)
    {
        echo "Database is not Connected!";
    }
   
?>
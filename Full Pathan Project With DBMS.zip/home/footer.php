<!DOCTYPE html>
<html>
<head>
<style>
@font-face {
            font-family: 'Li Ador Noirrit SemiBold';
            src: url('font/Li Ador Noirrit SemiBold.ttf'); /* Ensure your font path is correct */
        }
.footer {
    position: fixed;
    width: 100%;
    text-align: center;
    
    bottom: 0;
    background-color: #2ab7ca;
    color: white;
}
</style>
</head>

<body>
<footer class="footer">

  <p style="margin-top: 4px;margin-bottom:-10px">This is Made By Team RF 🤣ভাই TF মানে তামিম,ফারজানা not THE FU*K</p><br>
  <a href="https://www.pathanbd.rocks/home/contactUS.php" style="color:brown">ContactUs</a>

</footer>

</body>
</html>